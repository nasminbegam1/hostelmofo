
$.fullCalendar.lang("pt", {
	defaultButtonText: {
		month: "Mês",
		week: "Semana",
		day: "Dia",
		list: "Agenda"
	},
	allDayText: "Todo o dia",
	eventLimitText: "mais"
});
