
$.fullCalendar.lang("is", {
	defaultButtonText: {
		month: "Mánuður",
		week: "Vika",
		day: "Dagur",
		list: "Dagskrá"
	},
	allDayHtml: "Allan<br/>daginn",
	eventLimitText: "meira"
});
