
$.fullCalendar.lang("id", {
	defaultButtonText: {
		month: "Bulan",
		week: "Minggu",
		day: "Hari",
		list: "Agenda"
	},
	allDayHtml: "Sehari<br/>penuh",
	eventLimitText: "lebih"
});
