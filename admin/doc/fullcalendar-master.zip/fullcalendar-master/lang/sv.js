
$.fullCalendar.lang("sv", {
	defaultButtonText: {
		month: "Månad",
		week: "Vecka",
		day: "Dag",
		list: "Program"
	},
	allDayText: "Heldag",
	eventLimitText: "till"
});
